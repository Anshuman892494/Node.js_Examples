import express from 'express'
const app = express();
import path from 'path'
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const __filename = fileURLToPath(import.meta.url)

const __dirname = dirname(__filename)
import mongoose from 'mongoose'


const productSchema = new mongoose.Schema({
    name: String,
    price: Number
})

const Product = mongoose.model("products", productSchema)
mongoose.connect("mongodb://localhost:27017/")

app.use(express.urlencoded({ extended: true }))
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'CRUD_FORM.html')) //Html File name here
})

//Creation
app.post('/add', async (req, res) => {
    let data = new Product(req.body) //import from input tag
    let result = await data.save()

    res.send(
        `
        <h2>Product added Successfully</h2>
        <p><b>Name : </b> ${result.name}</p>
        <p><b>Price : </b> ${result.price}</p><br>
        <a href="/">Go Back</a>
    `
    )

})

// Read All Product
app.post('/read', async (req, res) => {
    const products = await Product.find();

    let table = `
        <h2>All Products</h2>
        <table border="1" cellpadding="10">
            <tr>
                <th>Id</th>
                <th>Name</th>
                <th>Price</th>
            </tr>
    `;

    products.forEach(p => {
        table += `
            <tr>
                <td>${p.id}</td>    
                <td>${p.name}</td>
                <td>${p.price}</td>
            </tr>
        `;
    });

    table += `
        </table>
        <br><a href="/">Go Back</a>
    `;

    res.send(table);
});

// Update Product (by ID)
app.post('/update', async (req, res) => {
    const updated = await Product.findByIdAndUpdate(
        req.body.id,
        {
            name: req.body.name,
            price: req.body.price
        },
        { new: true }
    );

    res.send(`
        <h2>Product Updated Successfully</h2>
        <p><b>Updated Name:</b> ${updated.name}</p>
        <p><b>Updated Price:</b> ${updated.price}</p>
        <br><a href="/">Go Back</a>
    `);
});


// Delete Product
app.post('/delete', async (req, res) => {
    const deleted = await Product.findByIdAndDelete(req.body.id);

    res.send(`
        <h2>Product Deleted Successfully</h2>
        <p><b>Deleted Product ID:</b> ${req.body.id}</p>
        <br><a href="/">Go Back</a>
    `);
});

//Starting server
app.listen(3000, () => {
    console.log("Server running on http://localhost:3000/");
});